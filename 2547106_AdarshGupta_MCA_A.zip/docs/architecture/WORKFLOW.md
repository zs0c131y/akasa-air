# Workflow

Every leave request moves through one state machine, implemented in `server/src/workflow.js`. Nothing else in the code decides what is allowed.

## States
| State | Meaning |
|---|---|
| `PENDING_MANAGER` | Waiting for the employee's manager |
| `PENDING_HOD` | Waiting for the Head of Department |
| `INFO_REQUESTED` | An approver asked a question; waiting for the employee |
| `APPROVED` | Finished: approved |
| `REJECTED` | Finished: rejected |
| `CANCELLED` | Finished: withdrawn by the employee |

```
 submit ──► PENDING_MANAGER ──approve (≤3 days)──────────────► APPROVED
                 │  │                                             ▲
                 │  └─approve (>3 days)──► PENDING_HOD ──approve──┘
                 │                            │   │
                 ├──reject──► REJECTED ◄──reject──┘   │
                 └──ask info──► INFO_REQUESTED ◄──ask info
                                   │  employee replies: back to the stage that asked
 Employee can cancel while open (or approved leave that has not started).
```

## Transitions
| Action | Who | From | To | Logged |
|---|---|---|---|---|
| Submit | Employee | – | `PENDING_MANAGER` | timeline + audit |
| Submit (manager's own leave) | Manager | – | `PENDING_HOD` | timeline + audit |
| Submit (HOD's own leave) | HOD | – | `APPROVED` (auto, flagged) | timeline + audit |
| Approve | The employee's manager | `PENDING_MANAGER` | `APPROVED` if ≤3 days, else `PENDING_HOD` | yes |
| Approve | HOD (not the requester) | `PENDING_HOD` | `APPROVED` | yes |
| Reject (comment required) | Manager / HOD at their stage | `PENDING_*` | `REJECTED` | yes |
| Ask for information (question required) | Manager / HOD at their stage | `PENDING_*` | `INFO_REQUESTED` | yes |
| Reply (text and/or documents) | Employee | `INFO_REQUESTED` | stage that asked | yes |
| Edit | Employee | open, before any approval | unchanged | yes |
| Send documents | Employee | open or approved | unchanged | yes |
| Cancel | Employee | open, or approved and not started | `CANCELLED` | yes |

Illegal moves return `409 ILLEGAL_TRANSITION`; permitted state but wrong person returns `403`. Nobody can act on their own request as an approver. Two people deciding at once is stopped by a version check (`409 STALE_REQUEST`).

## The long-leave rule
Days are counted inclusively, **except Sundays and public holidays, which are never counted as leave**. The holiday calendar lives in the database (`holidays` collection) and is kept by the HOD at `/holidays`; fixed-date national holidays (26 Jan, 15 Aug, 2 Oct, 25 Dec) are seeded the first time the server starts, and holidays that move (Diwali, Eid and so on) are added by the HOD once announced. Holidays are either national (apply to everyone) or tied to one location, and each person works from one location, so someone in Bengaluru is not charged for a Mumbai-only holiday. The HOD sets locations on the Holidays page (Locations and people tab); a person with no location gets national holidays only. The HOD can add holidays one at a time or paste or upload a list (Import a list tab), which is checked line by line before anything is saved. The server and the apply form count with the same function, and each request stores what was left out (`excluded`). A request keeps the count it had when it was filed, even if a holiday is added later. For example: Mon 2 Nov to Fri 6 Nov is **5 days**; Fri 6 Nov to Tue 10 Nov is **4 days** (the Sunday is skipped). A request that covers only Sundays and holidays is refused. Documents for emergency leave fall due on the next working day (a Sunday is skipped)

**Leave in a row.** Requests of the same person that touch (or are separated only by Sundays and public holidays) count together when deciding if leave is long, so splitting a 6-day leave into 3 + 3 does not skip the document or the HOD. The later request becomes the long one, and says why ("Together with your other leave ... this is 6 days in a row"). Requests already approved are not changed afterwards.

**The "more than 3 days" rule is about days in a row.** The assignment says "more than 3 consecutive leaves", so the rule looks at how many calendar days someone is away from the first day to the last, Sundays and holidays in the middle included. Friday to Monday is 4 days in a row even though only 3 are charged. Above 3 days in a row (`LONG_LEAVE_THRESHOLD_DAYS`), documents are required and both Manager and HOD must approve. Exactly 3 is short. What is *charged* to the person (`days`) still leaves out Sundays and public holidays.

**Split-up requests are caught.** If someone files Friday and Saturday, then Monday to Wednesday, the second request is judged together with the first (6 days in a row). It needs a document and the HOD's approval, is flagged to the approvers (`splitFlag`, "In a row with other leave"), and an audit entry `SPLIT_LEAVE_FLAGGED` is written.

**Documents** are only taken for leave over 3 days in a row. Shorter leave neither needs nor accepts a document (the form hides the upload box and the server refuses it).

## Emergency leave
Tick "Emergency leave" to file a long leave without documents. Both approvals are still needed. Documents are due by the day after the leave ends, or before the next leave.
- 0 leaves missing documents: apply for anything.
- 1 missing: only one more emergency leave is allowed; normal leave is blocked.
- 2 missing: all new leave is blocked until documents are uploaded.

## Worked examples
**2-day leave (4 to 5 Dec):** Arjun applies, no document needed. His manager Rahul approves with a comment. Status: `APPROVED`. Two steps.
**5-day leave (10 to 14 Dec):** Arjun applies. Without a document he is blocked with a friendly message; he attaches a ticket and submits (`PENDING_MANAGER`). Rahul asks "Which dates is the flight?" (`INFO_REQUESTED`). Arjun replies (back to `PENDING_MANAGER`). Rahul approves (`PENDING_HOD`). Priya, the HOD, approves (`APPROVED`).

## Leave allowance
Everyone gets **30 days a year** to begin with. The HOD can change the default, set a different number for one person, or paste or upload a list (`email,allowance,year`, and a line starting `default` for everyone). A request counts against the year it starts in. Charged days (not Sundays, not holidays) are used when approved and set aside while the request waits for an answer; rejecting, cancelling or editing a request gives the days back. A request that needs more days than are left is stopped with a message that says how many are left.

## Notifications
Each person has in-app notices (the bell in the header). They are created when:
- a request is filed (the manager, or the HOD for a manager's own request),
- a manager approves a long request (the employee is told it is now with the HOD, and the HOD is told it is waiting),
- a request is approved or rejected (the employee),
- an approver asks a question (the employee) and the employee replies (the approver),
- a request is cancelled (the approver it was waiting for).

Emails are sent for the same events only when Mailgun is configured, the person has not switched emails off on their Account page, and their address is real. Addresses ending in `.demo`, `.test`, `.example`, `.invalid`, `.local` or `.localhost`, and `example.com/.org/.net`, are never emailed (add more with `NO_EMAIL_DOMAINS`), so demo accounts cost no sending quota.

## Manager away
If a manager has approved leave covering the requested days (or today), an employee's request skips the manager and goes straight to the HOD, who answers **on behalf of that manager**. It also applies to waiting requests when the manager's own leave is approved. The history shows a "Passed to the HOD" entry by System, the request carries `onBehalfOf` (the manager's name, shown as a badge and a notice), the HOD's notification says to answer on that manager's behalf, and `LEAVE_REROUTED` is written to the audit log. Documents are still required for long leave.

## Overlap warning
When an approver opens a request, the API adds `overlaps`: how many other people on the same team (everyone with the same manager; for a manager's own leave, the other managers) are away on those days, who, and the team size without the requester. Employees never get this.

## Reports and export
`GET /api/stats/monthly` returns approved days, waiting days, requests and people per month (a request counts in the month it starts). `GET /api/leaves/export.csv` downloads requests as CSV for what the person may see, with spreadsheet formulas neutralised, and records the download in the audit log.

# Assignment requirements audit

Reviewed on 2026-11-06 against the assignment supplied in this conversation.

**Verdict: full compliance is not established.** Core features are implemented, but the current checkout fails its production build, the strict long-leave rule has exceptions, and executable delivery and browser/mobile acceptance remain incomplete or unverified.

This is a review, not a remediation. No application source was changed by this audit. Existing working-tree changes were preserved. Files changed during the review; the latest verification results below supersede the earlier successful build.

## Verification performed

| Check | Observed result |
|---|---|
| `npm.cmd test` (latest run) | PASS: 90 tests: shared 24, server 59, client 7 |
| `npm.cmd run build` (latest run) | FAIL: cannot resolve `../ticket.jsx` imported by `client/src/pages/LandingPage.jsx` |
| Earlier production build | Passed before subsequent working-tree changes; does not certify the current source |
| Earlier `npm.cmd start`, using isolated embedded MongoDB, temporary data directory and port 4107 | Started and seeded successfully |
| Earlier live HTTP checks | `/health` returned `{ "status": "ok", "db": "up" }`; `/` returned HTTP 200 and application HTML |
| Additional isolated API probes | Reproduced the document waiver, Sunday/holiday threshold behavior, adjacent-request behavior, manager/HOD own-leave exceptions, HOD information loop and manager document retrieval |
| Browser/desktop/mobile checks | Unverified: browser access host and native computer-use pipe unavailable |
| Docker execution | Unverified: Docker CLI exists, but Docker daemon pipe is unavailable |
| Fresh install on another assessment machine | Not performed |

PowerShell blocks `npm.ps1` under the current execution policy. Calling `npm.cmd` worked without changing that policy. Test databases and startup data were isolated from the configured application database.

## Requirement-by-requirement result

“Implemented” below means source and/or automated API/component evidence exists. It does not claim a successful browser end-to-end test.

| Assignment requirement | Result | Evidence and limits |
|---|---|---|
| Employee submits/applies for leave | Implemented | Apply page, POST `/api/leaves`, validation and API tests. Current build failure blocks clean delivery of the portal. |
| Employee views submitted requests / leave history | Implemented | `scope=mine`, paginated list, status filters and request detail timeline. Browser behavior unverified. |
| Employee checks request status | Implemented | Serialized workflow status, text labels, status chips and history. |
| Employee attaches necessary documents | Implemented with policy gap | Multipart uploads, content-signature/type checks, size/count limits and authenticated storage; emergency requests can omit documents. |
| Manager views all pending requests | Implemented for assigned team; scope unresolved | Queue filters by assigned manager and `PENDING_MANAGER`. HOD has a separate queue. The brief does not define team boundaries; global visibility for every manager is not implemented. |
| Manager approves leave | Implemented | Authorized workflow transition and API tests. Long ordinary employee leave advances to HOD. |
| Manager rejects leave | Implemented | Rejection is terminal; explanatory comment required. |
| Manager adds comments while approving/rejecting | Implemented | Comment input, server schemas and persisted timeline. Approval comment optional; rejection comment required. |
| Manager views documents | API verified; browser viewing unverified | Assigned manager retrieved an uploaded PDF with HTTP 200 and `application/pdf`; UI opens a fetched blob in a new tab. Actual browser rendering was not observed. |
| Manager asks for more information | Implemented | `REQUEST_INFO` -> `INFO_REQUESTED`; employee reply returns to originating approval stage. Manager path tested in suite; HOD path additionally probed. |
| Strict check for more than three consecutive leaves | Partial / policy unresolved | Threshold `>3` exists, but uses days excluding Sundays/holidays and considers individual requests, not an employee's continuous absence across adjacent requests. See findings. |
| Long leave requires supporting documents | Fails unconditional rule | A four-day emergency request was submitted and fully approved with zero documents. |
| Long leave requires manager AND HOD approval | Implemented for ordinary employee long leave; exceptions exist | Manager's own long leave receives only HOD approval; HOD's own long leave is auto-approved. Date-count/split behavior can also prevent escalation. |
| Fields: employeeName, fromDate, toDate, reason | Implemented | Shared schema, authenticated employee identity, stored fields and form submission. Employee name may be omitted in API input and is derived from the authenticated user; supplied mismatched names are rejected. |
| Workflow implementation | Implemented with strict-rule gaps | Central state machine, role checks, legal transitions, information loop and optimistic concurrency. |
| Form validation | Implemented | Date validity/order, no past starts, reason length, document constraints, overlap checking; shared and server tests pass. No claim of exhaustive malformed-input coverage. |
| CRUD development | Implemented with cancellation semantics | Create/read/update requests; cancellation preserves history. Physical deletion of leave requests is not exposed. The brief does not explicitly require physical deletion. |
| Usage of AI tools | Documented | `AI_USAGE.md` describes tools, prompts, decisions and review. Historical tool/model claims were not independently authenticated. |
| Code and system knowledge | Documentation exists; assessment needed | Architecture, API, workflow, deployment, testing and demo documentation are present. A developer's ability to explain the system cannot be certified by source inspection. |
| Executable supplied for assessment | Delivery gap | Runnable Node service and Docker build files exist. No standalone executable/installer or packaging script was found in project files outside dependencies/data. The brief does not define whether a Node/Docker service qualifies as its “executable”; that acceptance cannot be assumed. Current production build also fails. |
| README with run instructions | Present, with issues | Setup/start/Docker instructions and demo accounts exist. Node minimum contradicts package engine; PowerShell commands fail as written in this environment; see findings. |
| Bonus: audit logs | Implemented | Actor, timestamp, action, state changes, comments/details and IP; HOD-only listing and model-level append-only guards tested. Logging errors are caught, so this is not a guarantee of audit persistence if the database/log write fails. |
| Bonus: friendly error messages | Implemented | Structured API errors, field messages, error UI and tests. |
| Bonus: UI color coding | Implemented in source/component tests | Distinct status colors plus text labels; real visual appearance/contrast unverified. |
| Bonus: responsive web/mobile app | Source support present; unverified | Responsive grids/navigation and viewport configuration exist. No successful viewport, touch, overflow or real-device check was possible. |

## Findings and reproductions

### 1. Blocking: current production build fails

`client/src/pages/LandingPage.jsx:6` imports `LeaveTicket` from `../ticket.jsx`; `client/src/ticket.jsx` is absent in the latest inspected tree.

Run `npm.cmd run build`. Vite reports:

```text
Could not resolve "../ticket.jsx" from "src/pages/LandingPage.jsx"
```

`npm run setup` invokes this build, as does the Dockerfile. The passing tests do not cover importing/building the landing page. Repair the import/component dependency and rerun the production build before delivering.

### 2. High: emergency flag bypasses mandatory documents through final approval

Source: `shared/src/index.js:88`, `server/src/services/leaveService.js:219`, `server/src/workflow.js:94`.

Using an ordinary employee, submit 2026-12-01 through 2026-12-04 with a valid reason, `isEmergency=true`, and no files:

```text
Submission: HTTP 201, days=4, isLong=true, documents=0, PENDING_MANAGER
Manager approval: HTTP 200, PENDING_HOD, documents=0
HOD approval: HTTP 200, APPROVED, documents=0
```

The same four-day request without the emergency flag is correctly rejected with HTTP 400. The assignment supplied for this review specifies a strict document rule and provides no emergency exception. `AI_USAGE.md` records the waiver as an earlier developer decision; that documents its origin but does not establish compliance with this brief.

### 3. High: threshold uses a working-day policy absent from the brief

Source: `shared/src/index.js:57`, especially Sunday/holiday exclusions at lines 66-67.

Observed for 2026-12-04 through 2026-12-07 (four calendar days including Sunday): HTTP 201, `days=3`, `isLong=false`, no documents. Manager approval immediately produced `APPROVED` without HOD.

With a test holiday on 2026-12-02, the four-calendar-day range 2026-12-01 through 2026-12-04 also became a three-day request with no documents required.

The brief does not specify calendar days versus working days. Consequently, excluding Sundays/holidays cannot be silently accepted as the required meaning of “consecutive.” Leave balance charging and the strict escalation threshold may need separate calculations once that meaning is established.

### 4. High if continuous absence is intended: adjacent requests evade escalation

Source: `server/src/services/leaveService.js:196` checks overlapping ranges; it does not combine adjacent ranges when deciding `isLong`.

For the same employee, both requests were accepted without documents:

```text
2026-12-01 to 2026-12-02: HTTP 201, days=2, isLong=false
2026-12-03 to 2026-12-04: HTTP 201, days=2, isLong=false
```

This covers four consecutive working days. If the assignment's rule applies to the employee's continuous absence, this is a bypass. If it applies only within a single application, that interpretation must be explicit; the brief does not resolve it.

### 5. Approval policy exceptions for manager/HOD applicants

Source: `server/src/workflow.js:22`.

With documents attached, a manager's own four-day request started at `PENDING_HOD` and was approved by the HOD alone. A HOD's own four-day request started at `APPROVED` without human approval.

The assignment does not define the hierarchy for these applicants. These are observed additional policies, not evidence that every long request receives two approvals. Resolve whether these roles can apply and who approves their leave.

### 6. Assessment delivery and README need correction

Source: `package.json`, `README.md:5`, `Dockerfile`, `docker-compose.yml`.

- No packaged standalone executable was found. Existing execution requires Node and installed dependencies, or building a Docker image. A native `.exe` is not explicitly mandated by file extension, so its necessity remains an assessor acceptance question.
- The README states Node 20.11+, while the root package declares >=20.12. Verification here used Node v24.21.0; neither minimum was tested.
- The documented `npm` commands fail in this Windows PowerShell environment because scripts are disabled. `npm.cmd` succeeds without changing system policy.
- Embedded MongoDB requires an initial binary download, as the README does disclose. Offline first-run readiness is not established.
- Docker could not be run because its daemon is unavailable. Its build currently invokes the failing frontend build.

### 7. Additional packaging concern: local environment files enter Docker context

Source: `Dockerfile:8` (`COPY . .`) and `.dockerignore`.

`.dockerignore` does not exclude `.env` or `.env.*`. A local `.env` exists. Building this checkout would copy that file into the image; any credentials in it would be packaged. Exclude local environment files before distributing an image. Environment values were not printed or inspected as part of this finding.

## Acceptance still required

After resolving the build and strict-rule findings, verify a clean assessment-machine install/start, the agreed executable format, and browser flows at desktop and mobile sizes. Exercise upload and document opening, all decision paths, information replies, history/status updates, and the exact three/four-day boundary through the real UI. Until those checks succeed, do not describe every requirement as correctly and completely implemented.
